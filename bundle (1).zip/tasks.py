from robocorp.tasks import task
from robocorp import browser
import os

from RPA.HTTP import HTTP
import csv
from RPA.PDF import PDF
import shutil
import zipfile

@task
def order_robots_from_RobotSpareBin():
    """
    Orders robots from RobotSpareBin Industries Inc.
    Saves the order HTML receipt as a PDF file.
    Saves the screenshot of the ordered robot.
    Embeds the screenshot of the robot to the PDF receipt.
    Creates ZIP archive of the receipts and the images.
    """
    browser.configure(slowmo=10)
    open_RobotSpareBin_OrderForm()
    OrderFiles=read_order_list()
    zip_all_orders(OrderFiles)

def open_RobotSpareBin_OrderForm():
    browser.goto("https://robotsparebinindustries.com/#/robot-order")

def read_order_list():
    page = browser.page()
    http = HTTP()
    pdf = PDF()
    http.download(url="https://robotsparebinindustries.com/orders.csv", overwrite=True)
    """orders = Table.read_table_from_csv("orders.csv", header=True)"""
    Files=[]
    with open("orders.csv", newline="") as csvfile:
        orders=csv.DictReader(csvfile)
        for Order in orders:
            fill_in_form(Order)
            output_pdf_path=save_receipt_as_pdf(str(Order["Order number"]))
            screenshot_path=save_robot_screenshot(str(Order["Order number"]))
            target_doc="output/order_"+str(Order["Order number"])+".pdf"
            pdf.add_files_to_pdf(files=[output_pdf_path,screenshot_path],target_document=target_doc )
            os.remove(output_pdf_path)
            os.remove(screenshot_path)
            Files.append(target_doc)
            page.click("#order-another")
            page.wait_for_load_state()
    return Files


def fill_in_form(Order):
    page = browser.page()
    if page.locator("text=OK").is_visible():page.click("text=OK")
    page.select_option("#head", str(Order["Head"]))
    page.click("#id-body-"+str(Order["Body"]))
    page.fill("xpath=//div//label[text()='3. Legs:']//following-sibling::input",str(Order["Legs"]))
    page.fill("#address",str(Order["Address"]))
    page.click("#order")
    page.wait_for_load_state()
    alert_appeared=page.locator("div[class='alert alert-danger']").is_visible()
    i=0
    while alert_appeared:
        page.click("#order")
        alert_appeared=page.locator("div[class='alert alert-danger']").is_visible()
        i=i+1
        if i>5:break
   

def close_pop_up():
    page = browser.page()
    page.click("text=OK")

def save_receipt_as_pdf(order_number):
    page = browser.page()
    page.wait_for_load_state()
    order_receipt_html = page.locator("#receipt").inner_html()
    pdf = PDF()
    output_pdf_path="output/order_receipt_"+str(order_number)+".pdf"
    pdf.html_to_pdf(order_receipt_html, output_pdf_path)
    return output_pdf_path

def save_robot_screenshot(order_number):
    page = browser.page()
    page.wait_for_load_state()
    screenshot_path="output/robot_"+str(order_number)+".png"
    page.locator("#robot-preview-image").screenshot(path=screenshot_path)
    return screenshot_path

def zip_all_orders(Files):
    """shutil.make_archive("output/AllOrders","zip","output",dir)
    """
    with zipfile.ZipFile("output/AllOrders.zip", "w") as myzip:
        for file in Files:
            myzip.write(file)
            os.remove(file)
